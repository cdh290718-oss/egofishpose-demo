"""Comparable projections and honest acceptance report for the two-frame trial."""
from pathlib import Path
import sys,json,hashlib,base64,html,shutil,zipfile,re
import cv2,numpy as np
from guided import (OUT,ROOT,PREV,get_rows,context,read,write,load,geometry,smpl_x,SIDES,FACES,render,draw_geometry,JI,JOINT_MAPPING,rmse,metrics)
from run import read_obj,edge_counts,oriented_edges
WEB=OUT/'comparison';CHECKPOINT='b5c966263cae4e4add5d6de0c1e5f7c14d7583f0'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def label(im,s):
 a=np.full((im.shape[0]+32,im.shape[1],3),24,np.uint8);a[32:]=im;cv2.putText(a,s,(8,23),cv2.FONT_HERSHEY_SIMPLEX,.55,(245,245,245),1,cv2.LINE_AA);return a

def main():
 WEB.mkdir(exist_ok=True);sections=[];allstats=[];sheet=[];validations=[]
 for row in get_rows():
  key=row['condition']+'_cam3';src=OUT/'frames'/row['condition'];d=WEB/'images'/key;d.mkdir(parents=True,exist_ok=True)
  p0,source,rigid,w,old,matches,cam,lookup,data=context(row);p=load(src/'body_params.npz');new=load(src/'hybrid_mesh.npz');opt=read(src/'optimization.json');fusion=read(src/'fusion_report.json')
  v,j=geometry(p);objv,objf=read_obj(src/'hybrid_mesh.obj');bodyerr=float(np.abs(v-p['smplx_mesh_cam']).max());objerr=float(np.abs(objv-new['vertices_cam']).max());assert bodyerr<1e-5 and objerr<1e-7 and np.array_equal(objf,new['faces']);assert np.array_equal(old['faces'],new['faces'])
  cnt=edge_counts(new['faces']);direct=oriented_edges(new['faces']);seamgood=True
  for s in matches:
   ids=new[s+'_local_to_mesh'];seeds=set(map(int,ids[new[s+'_wrist_loop_local']]))
   for (a,b),n in cnt.items():
    if a in seeds and b in seeds:seamgood &= n==2 and direct[a,b]==direct[b,a]==1
  assert seamgood
  reload=read(src/'fusion_reload.json');assert reload['passed']
  im=cv2.imread(row['image']);imgs={};stats={}
  for stage,params,m in [('raw',load(row['raw_npz']),None),('sapiens',source,None),('previous',p0,old),('guided_body',p,None),('same_seam',p,load(src/'published_seam_mesh.npz')),('fusion',p,new)]:
   bv,bj=geometry(params);meshv=m['vertices_cam'] if m is not None else bv;faces=m['faces'] if m is not None else FACES
   image=render(im,meshv.astype(float),faces,cam,.12);imgs[stage]=image;cv2.imwrite(str(d/(stage+'.jpg')),image)
   hands={s:rmse(cam.world2camera((smpl_x.orig_hand_regressor[s]@meshv).astype(float)),w['joints_2d'][matches[s]['candidate']]) for s in matches}
   body=metrics(params,w,old,matches,cam,lookup,data)
   stats[stage]=dict(body_rmse_px=body['body_rmse_px'],hand_rmse_px=float(np.sqrt(np.mean(np.array(list(hands.values()))**2))),hands_rmse_px=hands)
  imgs['input']=im;cv2.imwrite(str(d/'input.jpg'),im)
  shutil.copyfile(src/'fusion_skeleton.jpg',d/'fusion_skeleton.jpg');shutil.copyfile(src/'optimization.json',d/'optimization.json');shutil.copyfile(src/'fusion_report.json',d/'fusion_report.json')
  for s,m in matches.items():
   elbow=lookup[s+'_elbow'];q=w['joints_2d'][m['candidate']];pt=.6*np.array([elbow['x'],elbow['y']])+.4*q[0];q=np.vstack([q,pt]);lo=np.maximum(0,np.floor(q.min(0)-35)).astype(int);hi=np.minimum([1280,720],np.ceil(q.max(0)+35)).astype(int)
   crops=[]
   for stage,title in [('input','Input'),('previous','Published baseline'),('guided_body','MANO-guided body'),('fusion','New fusion')]:
    crop=imgs[stage][lo[1]:hi[1],lo[0]:hi[0]];scale=min(400/crop.shape[1],420/crop.shape[0]);crop=cv2.resize(crop,None,fx=scale,fy=scale);canvas=np.full((420,400,3),24,np.uint8);canvas[:crop.shape[0],:crop.shape[1]]=crop;crops.append(label(canvas,title))
   cv2.imwrite(str(d/(s+'_detail.jpg')),np.concatenate(crops,axis=1))
  before=stats['previous'];after=stats['fusion'];numeric=dict(body_reload_max_abs_m=bodyerr,obj_npz_max_abs_m=objerr,topology_unchanged=True,seam_edges_two_opposite_faces=bool(seamgood),fixed_shape=bool(np.array_equal(p['betas'],p0['betas'])),independent_fusion_reload=reload,local_crossing_checks_passed=fusion['all_local_crossing_checks_passed'])
  rec=dict(frame=key,seconds=row['video_seconds'],metrics=stats,optimization=opt,fusion=fusion,validation=numeric);allstats.append(rec);validations.append(numeric)
  grid=lambda pairs:'<div class="grid">'+''.join(f'<figure><figcaption>{html.escape(title)}</figcaption><a href="images/{key}/{name}.jpg"><img loading="lazy" src="images/{key}/{name}.jpg"></a></figure>' for name,title in pairs)+'</div>'
  sec=f'<section><h2>{key} · {row["video_seconds"]:.3f} s</h2><p>身体自动点 RMSE：原发布融合基底 {before["body_rmse_px"]:.2f} → 新版 {after["body_rmse_px"]:.2f} px；最终手部自动点 RMSE：{before["hand_rmse_px"]:.2f} → {after["hand_rmse_px"]:.2f} px。</p>'
  sec+=grid([('input','原图'),('previous','GitHub 原发布融合'),('guided_body','MANO 辅助身体优化'),('fusion','新版融合候选')])
  sec+=f'<p>固定 MANO 腕口局部候选全部通过：{fusion["all_fixed_mano_patches_accepted"]}；局部非相邻三角形交叉检查通过：{fusion["all_local_crossing_checks_passed"]}。不通过时该侧保留原有有界接缝算法，不标为几何合格。</p>'
  sec+=grid([('left_detail','左手：相同区域放大'),('right_detail','右手：相同区域放大')])
  sec+='<details><summary>完整阶段及相同接缝算法消融</summary>'+grid([('raw','原始 EgoSMPLX'),('sapiens','原 Sapiens2 两阶段身体'),('same_seam','增强身体 + 原接缝算法'),('fusion_skeleton','新融合骨架')])+'</details></section>';sections.append(sec)
  sheet.append(label(np.concatenate([cv2.resize(imgs[k],(480,270)) for k in ['previous','guided_body','fusion']],axis=1),key+' | old fusion / guided body / new fusion'))
 cv2.imwrite(str(WEB/'contact_sheet.jpg'),np.concatenate(sheet,axis=0))
 write(WEB/'metrics.json',allstats);write(OUT/'delivery_validation.json',dict(checkpoint=CHECKPOINT,baseline_code_unchanged=all(sha(PREV/k)==v for k,v in read(PREV/'code_sha256.json').items()),frames=validations))
 report=['# MANO 辅助身体阶段：两帧实验','',f'原流程 checkpoint：`{CHECKPOINT}`；分支 `checkpoint/session-hand6-before-mano-guidance-20260929`。GitHub 原页面对应发布提交 `705008c`；源码及自动输入完全沿用原 session-hand6 流程。原文件、原网页均不覆盖。','',
 '## 方法','',
 '1. 复用 EgoSMPLX、Sapiens2、WiLoR、分割及左右手自动身份，权重和标定不变。以原发布流程的接缝前身体参数继续优化；不重新初始化身体，不使用人工目标。',
 '2. 保留 19 个 body_pose 关节和 global_orient/transl 的原始角度、深度、腕距约束，固定 betas、手指参数、脚和面部。增加 WiLoR 四个非拇指 MCP 掌根点及 MANO 腕环 16 个对应像素，联合保留身体点和可见前臂轮廓。二维 MANO 目标直接来自原网络投影，不平移到身体腕点。',
 '3. 损失：4×身体项 + 4×腕点 + 1×掌根 + 5×腕环 + 1.5×轮廓 + 姿态/平移先验。身体项为置信度加权 Huber(20 px) 加 0.15 倍平方误差；统一以 10000 归一化。权重是本次固定实验配置，不是已证实适用于任意图像的最优值。',
 '4. 延续优化使用 Adam、角度投影及非线性约束回退；身体 RMSE 上界取原两阶段值+5 px 与原发布身体值+0.5 px 的较小值。全局非凸问题，不宣称全局收敛；约束导致的停滞在逐步日志中保存。',
 '5. 为避免掌部目标拉离身体腕点，又比较了沿原优化结果回退的短程分支：把每只身体腕点的像素误差限制为原值+3 px。sample_03 使用此分支；sample_04 此限制阻碍原有错误深度的修正，身体 RMSE 回到 60.86 px，而初始增强分支的最终 MANO 手部、轮廓及局部几何均通过，因此保留 31.84 px 的初始增强分支。这里区分 SMPL-X 身体腕关节与最终 MANO 腕口；两帧均保持原解剖姿态增量、三维腕距和深度限制。此两帧对照不证明一种权重配置能自动泛化至任意图像。',
 '6. 接缝做两种输出：增强身体搭配原有有界接缝（消融）；再尝试完全保留原生 MANO 投影的固定腕口，在局部前臂做有界形变。仅 6/10/14 个邻接环内选局部支持，不变更身体初值。检查边长、面积、法向、最大 25.5 mm 位移、近裁面及局部非相邻三角形交叉。未通过的侧回退到原有接缝，保留失败诊断。',
 '7. MANO 的二维投影独立于身体，但三维根距离仍由拟合后的身体腕点提供。此单视角实验没有绝对深度真值，不能把这个距离当成独立 MANO 深度观测。','',
 '## 指标（像素）','', '| 帧 | 身体：原 Sapiens2 / 原发布融合基底 / 新身体 | 手部：原融合 / 新融合 | 固定 MANO 腕口全部通过 | 局部交叉通过 |','|---|---:|---:|---|---|']
 for r in allstats:
  s=r['metrics'];report.append(f'| {r["frame"]} | {s["sapiens"]["body_rmse_px"]:.2f} / {s["previous"]["body_rmse_px"]:.2f} / {s["fusion"]["body_rmse_px"]:.2f} | {s["previous"]["hand_rmse_px"]:.2f} / {s["fusion"]["hand_rmse_px"]:.2f} | {r["fusion"]["all_fixed_mano_patches_accepted"]} | {r["fusion"]["all_local_crossing_checks_passed"]} |')
 report+=['','RMSE 以同一组 Sapiens2/WiLoR 自动点为参考，非人工真值。标准 SMPL-X 手部点未重新拟合手指，其误差不能直接解释为身体拟合误差。手部融合最终指标从最终网格回归 21 个手部点后投影计算。','', '## 恢复与重现','',f'基线本地 commit：`{CHECKPOINT}`。新增实验在 `experiment/session-hand6-mano-guided-20260929` 分支；可用 `git diff {CHECKPOINT} -- <路径>` 检查差异。原流程源代码、8 帧自动缓存、原输出以及外部依赖源码快照已纳入 checkpoint；模型权重未复制，原路径及 SHA256 保存在基线 model_provenance.json。',
 'GitHub 同时保留恢复标签：[checkpoint-before-mano-guided-body-20260929](https://github.com/cdh290718-oss/egofishpose-demo/tree/checkpoint-before-mano-guided-body-20260929)。',
 '需要恢复具体旧脚本时：`git restore --source checkpoint/session-hand6-before-mano-guidance-20260929 -- <具体路径>`。本次未改写任何旧流程文件；继续运行原目录即可使用旧流程。不要用整库清理命令删除其他未跟踪实验。',
 '', '重建已交付结果：原 egosmplx Python 环境执行 `fusion.py --verify`。初始身体实验源码为 `guided_initial.py --steps 1400`；腕点保护分支为 `guided.py --steps 600 --continue-body --samples sample_03`，读入 diagnostic_before_image_wrist_guard 保存的初始实验身体参数。candidate_selection.json 记录两分支选择，诊断文件保留。然后执行 `fusion.py`、`fusion.py --verify`、`deliver.py`。新版最终融合必须加载 hybrid_mesh.npz/obj；body_params.npz 仅定义 SMPL-X 基底。',
 '', '验证范围：参数重载、OBJ/NPZ 一致、拓扑及接缝边连接；局部交叉只检测不共享顶点的非共面穿插，不保证全身无碰撞。数值通过不等于视觉满意。']
 (OUT/'RUN_REPORT_zh.md').write_text('\n'.join(report)+'\n');shutil.copyfile(OUT/'RUN_REPORT_zh.md',WEB/'RUN_REPORT_zh.md')
 doc='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MANO 辅助身体优化：两帧候选实验</title><style>body{background:#14191e;color:#edf2f7;font:16px/1.6 system-ui;margin:24px}a{color:#8dccff}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}figure{margin:0}img{width:100%;height:auto}section{margin:32px 0;border-top:1px solid #45525c;padding-top:16px}details{margin:16px 0}code{color:#9cd}@media(max-width:750px){.grid{grid-template-columns:1fr}}</style><h1>MANO 辅助身体优化：两帧候选实验</h1><p>基于原 GitHub session-hand6 流程继续优化，原流程保持不变。所有误差参考自动目标，不是人工真值；请同时检查轮廓和几何诊断。</p><p><a href="../session-hand6/">原发布页面</a> · <a href="RUN_REPORT_zh.md">方法与指标报告</a> · <a href="offline.html" download>单文件离线版</a> · <a href="results_bundle.zip">结果下载</a></p><p>恢复 checkpoint：<code>'+CHECKPOINT+'</code></p>'+''.join(sections)+'</html>'
 (WEB/'index.html').write_text(doc)
 offline=doc
 for rel in set(re.findall(r'(?:src|href)="(images/[^\"]+\.jpg)"',doc)):
  offline=offline.replace('"'+rel+'"','"data:image/jpeg;base64,'+base64.b64encode((WEB/rel).read_bytes()).decode()+'"')
 (WEB/'offline.html').write_text(offline)
 with zipfile.ZipFile(WEB/'results_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in OUT.rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and 'comparison' not in p.parts and p.suffix not in ['.log']:z.write(p,str(p.relative_to(OUT)))
  for p in WEB.rglob('*'):
   if p.is_file() and p.suffix in ['.jpg','.html','.md','.json'] and p.name!='offline.html':z.write(p,'comparison/'+str(p.relative_to(WEB)))
 print('DELIVERED',json.dumps([{'frame':r['frame'],'metrics':r['metrics']} for r in allstats]),flush=True)
if __name__=='__main__':main()
