"""Keep the published bounded seam, audit it; also test a fixed MANO boundary.
No target is derived from a manual annotation. All selection thresholds are saved.
"""
import sys,time,importlib.util,argparse
from pathlib import Path
import numpy as np,torch,cv2
import torch.nn.functional as TF
from guided import (OUT,ROOT,PREV,get_rows,context,read,write,load,geometry,stitch,smpl_x,SIDES,FACES,render,draw_geometry,write_obj,arr,rmse)
from silhouette import metrics as sil_metrics
from contour_seam import build as old_build,adjacency,distance,harmonic,normals,edges,hand_metrics
from tools.force_replace_smplx_hand_mesh_with_wilor import native_projection
spec=importlib.util.spec_from_file_location('surface_audit',ROOT/'experiments/session_hand6_sample04_cam3_mano_wrist_20260926_v1/audit_mesh.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
spec=importlib.util.spec_from_file_location('local_solver',ROOT/'experiments/session_hand6_sample04_cam3_mano_wrist_20260926_v1/refine.py');local=importlib.util.module_from_spec(spec);spec.loader.exec_module(local)

def lift_unshifted(w,k,cam,root_distance):
 native=w['vertices_3d_local'][k]+w['cam_t'][k];joint=w['joints_3d_local'][k]+w['cam_t'][k]
 uv=native_projection(native);d=np.maximum(.05,root_distance+np.linalg.norm(native,axis=1)-np.linalg.norm(joint[0]));v=cam.camera2world(uv,d)
 assert (v[:,2]>0).all();v*=np.maximum(1,.020001/v[:,2])[:,None]
 return v.astype(np.float64),uv

def refine_patch(base,target,ids,seeds,free,bf,adj,cam,data,init):
 support=np.r_[seeds,free];fs=bf[np.isin(bf,support).any(1)];used=np.unique(fs);inv=np.full(len(base),-1,int);inv[used]=np.arange(len(used))
 fi=torch.tensor(inv[fs]);ei=torch.tensor(inv[edges(fs)]);ix=torch.tensor(inv[free]);reference=torch.tensor(base[used],dtype=torch.float64);initial=init.copy();initial[ids]=target
 fixed=torch.tensor(initial[used],dtype=torch.float64);x=torch.nn.Parameter(fixed[ix].clone());start=x.detach().clone()
 n0=torch.cross(reference[fi[:,1]]-reference[fi[:,0]],reference[fi[:,2]]-reference[fi[:,0]],dim=1);a0=n0.norm(dim=1);e0=(reference[ei[:,0]]-reference[ei[:,1]]).norm(dim=1)
 lap=np.zeros((len(used),len(used)))
 for i,globalid in enumerate(used):
  ns=adj[globalid]
  if ns:
   lap[i,i]=1
   for n in ns:
    if inv[n]>=0:lap[i,inv[n]]=-1/len(ns)
 lap=torch.tensor(lap,dtype=torch.float64);full=torch.tensor(base,dtype=torch.float64)
 prepared=[]
 for d in data:prepared.append((torch.tensor(d['ids']),torch.tensor(d['outside'],dtype=torch.float64)[None,None],torch.tensor(d['contour'],dtype=torch.float64)))
 opt=torch.optim.LBFGS([x],lr=.5,max_iter=220,tolerance_grad=1e-10,tolerance_change=1e-12,line_search_fn='strong_wolfe')
 def closure():
  opt.zero_grad();v=fixed.clone();v[ix]=x;nn=torch.cross(v[fi[:,1]]-v[fi[:,0]],v[fi[:,2]]-v[fi[:,0]],dim=1);er=(v[ei[:,0]]-v[ei[:,1]]).norm(dim=1)/e0;ar=nn.norm(dim=1)/a0;dot=(nn*n0).sum(1)/a0.square()
  loss=.03*((x-start)/.01).square().mean()+.03*(lap@(v-reference)/.003).square().mean()
  loss+=200*(TF.relu(.50-er).square().sum()+TF.relu(er-1.38).square().sum()+TF.relu(.25-ar).square().sum()+TF.relu(ar-2.15).square().sum()+TF.relu(.03-dot).square().sum())
  loss+=100*TF.relu((v-reference).norm(dim=1)/.025-1).square().sum()
  fullv=full.clone();fullv[torch.tensor(used,dtype=torch.long)]=v
  for idx,mp,goal in prepared:
   uv=cam.world2camera_pytorch(fullv[idx]);grid=uv/uv.new_tensor([1279,719])*2-1;outside=TF.grid_sample(mp,grid.reshape(1,1,-1,2),align_corners=True,padding_mode='border').reshape(-1)
   loss+=.5*(outside/10).square().mean()+.5*(torch.cdist(goal[None],uv[None])[0].min(1).values/10).square().mean()
  loss.backward();return loss
 opt.step(closure);result=initial.copy();result[free]=arr(x);return result

def patch_quality(v,ref,bf,support,cam,data,target,ids,loop,w,k):
 fs=bf[np.isin(bf,support).any(1)];ee=edges(fs);n0=normals(ref,fs);nn=normals(v,fs)
 er=np.linalg.norm(v[ee[:,0]]-v[ee[:,1]],axis=1)/np.linalg.norm(ref[ee[:,0]]-ref[ee[:,1]],axis=1);ar=np.linalg.norm(nn,axis=1)/np.maximum(1e-12,np.linalg.norm(n0,axis=1));disp=np.linalg.norm(v[support]-ref[support],axis=1)
 return dict(edge_min=float(er.min()),edge_max=float(er.max()),area_min=float(ar.min()),area_max=float(ar.max()),flipped=int((np.sum(n0*nn,axis=1)<=0).sum()),max_body_displacement_m=float(disp.max()),hand_target_max_abs_m=float(np.abs(v[ids]-target).max()),min_z_m=float(v[:,2].min()),silhouette=sil_metrics(v,cam,data))

def run(row,verify=False):
 dst=OUT/'frames'/row['condition'];p0,source,rigid,w,old,matches,cam,lookup,data=context(row);p=load(dst/'body_params.npz');v,j=geometry(p)
 published,report=old_build(p,w,matches,cam,data);published['method']=np.array('MANO_guided_body_plus_published_bounded_contour_seam')
 if not verify:np.savez_compressed(dst/'published_seam_mesh.npz',**published);write(dst/'published_seam_report.json',report)
 current=published['vertices_cam'].astype(float).copy();base,_=stitch(p,w,matches,cam);new=base.copy();new['method']=np.array('MANO_guided_body_fixed_native_MANO_boundary_small_forearm_patch');records={};accepted_all=True
 allhand=np.concatenate([base[s+'_local_to_mesh'] for s in matches]);bf=FACES[~np.isin(FACES,allhand).all(1)];adj=adjacency(bf,len(v));weights=smpl_x.layer['neutral'].lbs_weights.detach().numpy()
 selected=read(dst/'fusion_report.json') if verify else None
 for s,m in matches.items():
  si=SIDES.index(s);ids=base[s+'_local_to_mesh'];loop=base[s+'_wrist_loop_local'];seeds=ids[loop];target,uv=lift_unshifted(w,m['candidate'],cam,np.linalg.norm(j[12+si]));d=distance(adj,seeds);eligible=(weights[:,18+si]+weights[:,20+si]>.5)&~np.isin(np.arange(len(v)),allhand)
  ref=v.astype(float).copy();ref[np.setdiff1d(allhand,ids)]=current[np.setdiff1d(allhand,ids)];sdata=[q for q in data if q['side']==s];c=dict(v=ref,seeds=seeds,target=target,loop=loop,adj=adj,ids=ids,bf=bf)
  rows=[];options=[]
  rings_list=[selected['hands'][s]['selected']['rings']] if verify and selected['hands'][s].get('selected') else [6,10,14]
  for rings in rings_list:
   free=np.flatnonzero((d>0)&(d<rings)&eligible);support=np.r_[seeds,free]
   init=ref+local.similarity_warp(c,free);init[ids]=target
   candidate=refine_patch(ref,target,ids,seeds,free,bf,adj,cam,sdata,init)
   q=patch_quality(candidate,ref,bf,support,cam,sdata,target,ids,loop,w,m['candidate']);q['rings']=rings;q['free_vertices']=len(free)
   geom=bool(q['edge_min']>=.49 and q['edge_max']<=1.4 and q['area_min']>=.24 and q['area_max']<=2.2 and q['flipped']==0 and q['max_body_displacement_m']<=.0255 and q['min_z_m']>=.02)
   if geom:q['intersection_check']=audit.local_intersections(candidate,published['faces'],support);geom=q['intersection_check']['proper_crossings']==0
   q['passed']=geom;q['score']=sum(a['score'] for a in q['silhouette'].values());rows.append(q)
   print(row['condition'],s,q,flush=True)
   if geom:options.append((q,candidate,free,support))
  if options:
   q,candidate,free,support=min(options,key=lambda a:a[0]['score']);reset=np.flatnonzero((d>0)&(d<14)&~np.isin(np.arange(len(v)),allhand));current[reset]=v[reset];current[ids]=candidate[ids];current[free]=candidate[free];new[s+'_lifted_vertices']=target.astype(np.float32);new[s+'_target_vertex_uv']=uv.astype(np.float32);new[s+'_transition_body_vertex_ids']=free
   records[s]=dict(accepted=True,selected=q,candidates=rows)
  else:
   accepted_all=False;records[s]=dict(accepted=False,selected=None,candidates=rows,fallback='published bounded seam on improved body; fixed MANO boundary candidate rejected')
   # Retain the complete old seam for that side rather than report an invalid hard boundary as accepted.
  new[s+'_loop_support_vertex_ids']=np.flatnonzero(((d>=0)&(d<14)&eligible)|np.isin(np.arange(len(v)),seeds))
 new['vertices_cam']=current.astype(np.float32);new['faces']=published['faces'];new['body_joints_cam']=j;new['hand_joints_cam']=np.stack([smpl_x.orig_hand_regressor[s]@current for s in SIDES]).astype(np.float32)
 for s in matches:
  if s+'_blend_weights' in new:new.pop(s+'_blend_weights')
 checks={}
 for s in matches:
  support=new[s+'_loop_support_vertex_ids'];checks[s]=dict(before=audit.local_intersections(old['vertices_cam'].astype(float),old['faces'],support),after=audit.local_intersections(new['vertices_cam'].astype(float),new['faces'],support))
 rec=dict(manual_inputs=False,all_fixed_mano_patches_accepted=accepted_all,hands=records,intersection_checks=checks,silhouette_before=sil_metrics(old['vertices_cam'],cam,data),silhouette_after=sil_metrics(new['vertices_cam'],cam,data),all_local_crossing_checks_passed=all(q['after']['proper_crossings']==0 for q in checks.values()))
 if verify:
  saved=load(dst/'hybrid_mesh.npz');diff=float(np.max(np.abs(saved['vertices_cam']-new['vertices_cam'])));assert diff<1e-7,diff
  write(dst/'fusion_reload.json',dict(passed=True,mesh_vertex_max_abs_m=diff,reconstructed_in_independent_process=True))
 else:
  np.savez_compressed(dst/'hybrid_mesh.npz',**new);write_obj(dst/'hybrid_mesh.obj',new['vertices_cam'],new['faces']);write(dst/'fusion_report.json',rec)
  im=cv2.imread(row['image']);cv2.imwrite(str(dst/'fusion_wireframe.jpg'),render(im,new['vertices_cam'].astype(float),new['faces'],cam,.12));cv2.imwrite(str(dst/'fusion_skeleton.jpg'),draw_geometry(im.copy(),cam,new));cv2.imwrite(str(dst/'published_seam_wireframe.jpg'),render(im,published['vertices_cam'].astype(float),published['faces'],cam,.12))
 print('FUSION_DONE',row['condition'],accepted_all,rec['all_local_crossing_checks_passed'],flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--verify',action='store_true');ap.add_argument('--samples',nargs='*',default=['sample_03','sample_04']);a=ap.parse_args()
 for row in get_rows():
  if row['condition'] in a.samples:run(row,a.verify)
