from pathlib import Path
import json,hashlib,base64,re,shutil,zipfile,html,csv,io
OUT=Path(__file__).resolve().parent;WEB=OUT/'comparison'
def read(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
rows=read(WEB/'metrics.json');decision={};lines=[]
for r in rows:
 name=r['frame'];b=r['metrics']['previous'];a=r['metrics']['fusion'];fr=r['fusion'];accepted=fr['all_fixed_mano_patches_accepted'] and fr['all_local_crossing_checks_passed'] and a['body_rmse_px']<=b['body_rmse_px']+.5 and a['hand_rmse_px']<=b['hand_rmse_px']+3
 decision[name]={'accepted_improvement_candidate':bool(accepted),'original_page_replaced':False,'status':'局部几何检查通过，保留为改进候选' if accepted else '未通过整体验收，仅作诊断；不建议替换原流程'}
 lines.append(f"- {name}：{decision[name]['status']}。身体 RMSE {b['body_rmse_px']:.2f} → {a['body_rmse_px']:.2f} px，最终手部 RMSE {b['hand_rmse_px']:.2f} → {a['hand_rmse_px']:.2f} px。")
summary='\n'.join(['## 最终结论','',*lines,'','sample_04 右前臂的大鼓包明显减轻，但腕口近端仍可见局部收窄/折线感，不能说外形已完全自然。sample_03 身体小幅改善，手部误差略升，原有接缝仍有局部穿插；固定 MANO 腕口候选因位移或法向等限制被拒绝。','', '## 冻结可见前臂区域的轮廓检查','', '| 帧 / 侧 | 越出皮肤区域 RMS：原 / 新(px) | 边界覆盖 RMS：原 / 新(px) | 局部非相邻面交叉：原 / 新 |','|---|---:|---:|---:|'])
for r in rows:
 for side in ['left','right']:
  before=r['fusion']['silhouette_before'][side];after=r['fusion']['silhouette_after'][side];x=r['fusion']['intersection_checks'][side]
  summary+=f"\n| {r['frame']} / {side} | {before['outside_rms_px']:.2f} / {after['outside_rms_px']:.2f} | {before['boundary_coverage_rms_px']:.2f} / {after['boundary_coverage_rms_px']:.2f} | {x['before']['proper_crossings']} / {x['after']['proper_crossings']} |"
summary+='\n\n轮廓指标只覆盖原流程冻结的可见前臂截面与顶点集合，未包含整个人体轮廓，也不是独立人工真值。三角形交叉检查范围和排除项见方法说明。\n'
write(OUT/'acceptance_decision.json',decision);write(WEB/'acceptance_decision.json',decision)
report=(OUT/'RUN_REPORT_zh.md').read_text().split('\n<!-- FINAL_REVIEW -->')[0]+'\n<!-- FINAL_REVIEW -->\n'+summary
(OUT/'RUN_REPORT_zh.md').write_text(report);(WEB/'RUN_REPORT_zh.md').write_text(report)
visual='\n'.join(['# 两帧网格叠加检查','',*lines,'','检查图：每帧原图、原发布融合、新身体、新融合，以及左右手同区域裁剪。','', 'sample_04 右侧：原版腕口/前臂明显宽于真实皮肤；新身体已经修正了主要位置与投影尺度，固定 MANO 腕口后的融合更贴近前臂边界。腕口附近仍有局部收窄，未证明完全自然。左侧变化较小。','', 'sample_03：保留原有接缝后，手腕与前臂仍存在不自然过渡，手附近仍叠着身体其他区域的网格；新固定 MANO 候选未通过形变限制，不能只根据身体 RMSE 略降宣布成功。','', '原页面不覆盖；sample_03 新结果仅供定位问题，建议继续保留旧流程作为默认。'])+'\n'
(OUT/'VISUAL_REVIEW_zh.md').write_text(visual);(WEB/'VISUAL_REVIEW_zh.md').write_text(visual)
text=(WEB/'index.html').read_text();start='<!-- FINAL_STATUS -->';end='<!-- /FINAL_STATUS -->'
text=re.sub(start+'.*?'+end,'',text,flags=re.S)
notice=start+'<div style="padding:16px;border:2px solid #8199ad"><b>结果判定</b><ul>'+''.join('<li>'+html.escape(x[2:])+'</li>' for x in lines)+'</ul><p>sample_04 大鼓包明显减轻，腕口仍有局部收窄；sample_03 未通过表面验收。原发布流程和页面保持不变。</p><p><a href="VISUAL_REVIEW_zh.md">网格叠加检查记录</a> · <a href="https://github.com/cdh290718-oss/egofishpose-demo/tree/checkpoint-before-mano-guided-body-20260929">GitHub 恢复标签</a></p></div>'+end
text=text.replace('<h1>',notice+'<h1>',1)
for r in rows:
 if not decision[r['frame']]['accepted_improvement_candidate']:
  needle=f"<h2>{r['frame']} · {r['seconds']:.3f} s</h2>"
  text=text.replace(needle,needle+'<p style="color:#ffb2a9;font-weight:700">未通过表面验收，仅作诊断；不建议替换原结果。</p>')
(WEB/'index.html').write_text(text)
offline=text
for rel in set(re.findall(r'(?:src|href)="(images/[^\"]+\.jpg)"',text)):
 offline=offline.replace('"'+rel+'"','"data:image/jpeg;base64,'+base64.b64encode((WEB/rel).read_bytes()).decode()+'"')
(WEB/'offline.html').write_text(offline)
code={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.py')};write(OUT/'code_sha256.json',code)
validation=read(OUT/'delivery_validation.json');validation['decisions']=decision;validation['all_frames_accepted_as_improvements']=all(q['accepted_improvement_candidate'] for q in decision.values());write(OUT/'delivery_validation.json',validation)
with zipfile.ZipFile(WEB/'results_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and 'comparison' not in p.parts and p.suffix not in ['.log']:z.write(p,str(p.relative_to(OUT)))
 for p in WEB.rglob('*'):
  if p.is_file() and p.suffix in ['.jpg','.html','.md','.json'] and p.name!='offline.html':z.write(p,'comparison/'+str(p.relative_to(WEB)))
with zipfile.ZipFile(WEB/'results_bundle.zip') as z:assert z.testzip() is None
missing=[]
for rel in set(re.findall(r'(?:src|href)="([^\"]+)"',text)):
 if rel.startswith(('http','data:','../','#')):continue
 if not (WEB/rel).exists():missing.append(rel)
assert not missing,missing
write(OUT/'package_validation.json',dict(all_local_html_assets_exist=True,zip_crc_passed=True,offline_images_embedded=True,zip_bytes=(WEB/'results_bundle.zip').stat().st_size))
print(json.dumps(decision,ensure_ascii=False),flush=True)
