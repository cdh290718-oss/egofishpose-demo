"""Render matching crops, report checks, and package a standalone comparison."""
from pathlib import Path
import base64, hashlib, html, json, mimetypes, re, shutil, zipfile
import cv2
import numpy as np

OUT=Path(__file__).resolve().parent
PREV=OUT.parent/'session_hand6_full_pipeline_20260926_v1'
WEB=OUT/'comparison'

def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    result=read(OUT/'result.json');before=result['before'];after=result['after']
    checks=read(OUT/'reload_validation.json');surface=read(OUT/'surface_validation.json')
    assert checks['passed'] and checks['body_params_sha256_unchanged'] and surface['passed']
    crop=read(OUT/'crop.json');x0,y0,x1,y1=[crop[k] for k in ['x0','y0','x1','y1']]
    tiles=[]
    for name in ['input','before','after']:
        im=cv2.imread(str(WEB/(name+'.jpg')))[y0:y1,x0:x1]
        scale=500/im.shape[0];im=cv2.resize(im,(round(im.shape[1]*scale),500))
        tile=np.full((536,im.shape[1],3),24,np.uint8);tile[36:]=im
        cv2.putText(tile,name,(8,26),cv2.FONT_HERSHEY_SIMPLEX,.7,(245,245,245),1,cv2.LINE_AA);tiles.append(tile)
    cv2.imwrite(str(WEB/'right_wrist_comparison.jpg'),np.concatenate(tiles,axis=1))
    original_record=read(PREV/'comparison/images/sample_04_cam3/metrics.json')
    body_rmse=original_record['metrics']['fusion']['body_rmse_px']
    metrics=[('腕口半径 / MANO 腕口半径','wrist_to_mano_radius_ratio','倍'),
             ('腕口超出自动分割区域 RMS','wrist_loop_outside_rms_px','px'),
             ('右手 21 点 RMSE','right_hand_rmse_px','px')]
    lines=['| 指标 | 修改前 | 本次 |','|---|---:|---:|']
    rows=[]
    for title,key,unit in metrics:
        b=f'{before[key]:.3f} {unit}';a=f'{after[key]:.3f} {unit}'
        lines.append(f'| {title} | {b} | {a} |');rows.append(f'<tr><td>{title}</td><td>{b}</td><td>{a}</td></tr>')
    contour=read(OUT/'contour_comparison.json')
    for title,key in [('可见前臂越界 RMS','visible_forearm_outside_rms_px'),('可见前臂轮廓覆盖 RMS','visible_forearm_boundary_coverage_rms_px')]:
        b=contour['before'][key];a=contour['after'][key]
        lines.append(f'| {title} | {b:.3f} px | {a:.3f} px |')
        rows.append(f'<tr><td>{title}</td><td>{b:.3f} px</td><td>{a:.3f} px</td></tr>')
    crossing_before=surface['before']['proper_crossings'];crossing_after=surface['after']['proper_crossings']
    lines.append(f'| 局部非相邻三角面穿插对数 | {crossing_before} | {crossing_after} |')
    rows.append(f'<tr><td>局部非相邻三角面穿插对数</td><td>{crossing_before}</td><td>{crossing_after}</td></tr>')
    report=f'''# sample_04_cam3 · 67.947 s：以 MANO 腕口为准的局部融合

仅处理本帧右腕。按用户要求将 MANO 腕口作为硬边界，沿身体前臂调整局部表面；没有身体重新初始化，没有人工标注。

## 最终方法

1. 读取已完成的身体参数、WiLoR 自动预测、鱼眼标定及自动左右手身份。身体参数逐字节保留，左手和局部区域之外的网格逐顶点保留。
2. 沿用原流程在当前身体腕点距离处提升得到的 MANO 网格。右手全部 778 个顶点固定为该 MANO 目标，包含 16 个腕口顶点，目标未被放大以迎合身体。
3. 以 MANO 腕口为 Dirichlet 边界，先求前臂位移，再仅优化局部表面。使用已有 Sapiens2 分割合并区域、可见前臂截面、位移平滑项、边长/面积/法向约束。身体姿态和位置没有重新优化。
4. 对轮廓优化结果检查三角面穿插；若不合格，就从无穿插的局部过渡向它逐步调整，按同一轮廓指标选取通过几何检查的步长。本次取 15% 的过渡步长。最终为 `{after['method']}`，影响 {after['free_forearm_vertices']} 个身体前臂顶点，局部支持范围为 {after['rings']} 个拓扑环。这些是小规模局部表面求解，不是身体多起点拟合。
5. 因硬 MANO 腕口与旧标准腕口存在尺寸冲突，移除右腕 85%–115% 标准半径限制；局部边长比下限由 0.70 改为 0.20，面积比下限由 0.40 改为 0.08，允许腕口收缩。边长上限 1.40、面积上限 2.20、正深度和法向方向检查保留。此处为明确的方法变更，不能称为所有旧表面限制均未改变。

## 对比

{chr(10).join(lines)}

身体自动点 RMSE 仍为 {body_rmse:.2f} px；这个实验只处理右腕局部，不能据此宣称身体位置误差已修复。右手 RMSE 由最终网格回归关节点计算；SMPL-X 回归器也可能包含少量前臂顶点贡献，因此即使 MANO 顶点固定，该指标仍可能小幅变化。

可见前臂的轮廓覆盖误差由 5.54 升至 9.65 px，说明本次腕口改善没有带来整条前臂轮廓的全面改善。

以上指标参考 WiLoR 自动点或 Sapiens2 自动分割，不是人工真值。腕口超出分割区域 RMS 是单向越界量，较小不代表完整轮廓完全准确；腕口与 MANO 的一致性为本次硬约束，不能单独用作独立精度证明。

## 几何与重载

- 独立进程重新执行局部融合，与保存 NPZ 各字段逐项一致；OBJ 最大坐标差 {checks['obj_max_abs_m']:.3g} 米。
- 身体参数文件 SHA256 一致，右手 778 顶点与提升后的 MANO 目标逐项一致，接缝每条边由方向相反的两个面共享。
- 最终局部前臂边长比范围 {after['forearm_edge_ratio_min']:.3f}–{after['forearm_edge_ratio_max']:.3f}；面积比范围 {after['forearm_area_ratio_min']:.3f}–{after['forearm_area_ratio_max']:.3f}；相对修改前法向反向数 {after['forearm_normals_opposite_previous']}。
- 局部非相邻三角面穿插检查：{crossing_before} → {crossing_after} 对。检查范围是一面接触修改区域、另一面来自完整网格；跳过共享顶点面，不覆盖共面重叠，也不是全身无自交证明。

## 使用与复现

- `comparison/index.html`：在线对比；`comparison/offline.html`：图片已内嵌的单文件版。
- `hybrid_mesh.npz` / `hybrid_mesh.obj`：本次融合网格；`body_params.npz`：未改变的身体参数。
- 标准 SMPL-X 身体参数本身不能重建 MANO 与局部表面，读取混合网格或执行 `refine.py`。
- 在 EgoSMPLX 项目目录，使用 `miniconda3/envs/egosmplx/bin/python` 依次运行本实验的 `refine.py`、`refine.py --verify`、`audit_mesh.py`。脚本读取相邻旧实验的自动预测与模型资源；完整路径和输入校验和在 `result.json` 中。

## 实际限制

MANO 的三维放置仍继承当前身体腕点距离，没有重新估计绝对深度。本次验证的是让局部身体表面适应 MANO 边界的效果；原身体的肩部位置、整条手臂的三维姿态，以及自动分割误差，仍会限制最终轮廓精度。腕口鼓包得到改善，但放大图仍能看到腕口下方前臂过渡的偏折，不能把本次局部修改当作整条手臂已准确重建。
'''
    (OUT/'RUN_REPORT_zh.md').write_text(report)
    for name in ['RUN_REPORT_zh.md','result.json','reload_validation.json','surface_validation.json','VISUAL_REVIEW_zh.md','contour_comparison.json']:
        shutil.copyfile(OUT/name,WEB/name)
    css='body{background:#141a20;color:#e7edf3;font:16px/1.65 system-ui;margin:24px;max-width:1500px}a{color:#8ecaff}img{max-width:100%;display:block}.grid{display:grid;grid-template-columns:repeat(3,minmax(240px,1fr));gap:8px;overflow:auto}figure{margin:0}figcaption{padding:8px}td,th{padding:8px;border:1px solid #58616b}table{border-collapse:collapse}summary{cursor:pointer;margin-top:24px}'
    page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>sample_04_cam3 · MANO 腕口局部融合</title><style>'+css+'</style>'
    page+='<h1>sample_04_cam3 · 67.947 s</h1><p>右腕以 MANO 为边界，身体前臂局部平滑调整。全自动；身体参数固定；本次没有重新初始化身体。</p><p><a href="RUN_REPORT_zh.md">方法与验收报告</a> · <a href="VISUAL_REVIEW_zh.md">视觉检查与残留问题</a> · <a href="offline.html" download>单文件离线版</a> · <a href="results_bundle.zip" download>参数、网格与脚本</a> · <a href="../session-hand6/">原八帧结果</a></p>'
    page+='<h2>同一区域：原图 / 修改前 / 本次</h2><a href="right_wrist_comparison.jpg"><img src="right_wrist_comparison.jpg"></a>'
    page+='<p>腕口与手部的对接改善；腕口下方的前臂仍有明显偏折，整条手臂尚未准确贴合。下列误差参考自动预测，并非人工真值。</p><table><tr><th>指标</th><th>修改前</th><th>本次</th></tr>'+''.join(rows)+'</table>'
    page+='<h2>全图</h2><div class="grid">'+''.join(f'<figure><figcaption>{title}</figcaption><a href="{name}.jpg"><img src="{name}.jpg"></a></figure>' for name,title in [('input','原图'),('before','修改前'),('after','本次：MANO 腕口固定')])+'</div>'
    page+='<details><summary>骨架叠加与验收</summary><div class="grid">'+''.join(f'<figure><figcaption>{title}</figcaption><a href="{name}_skeleton.jpg"><img src="{name}_skeleton.jpg"></a></figure>' for name,title in [('before','修改前'),('after','本次')])+'</div><p><a href="reload_validation.json">独立重建检查</a> · <a href="surface_validation.json">局部穿插检查</a> · <a href="result.json">数值与输入来源</a></p></details></html>'
    (WEB/'index.html').write_text(page)
    offline=page.replace('<a href="offline.html" download>单文件离线版</a>','当前文件已内嵌图片').replace('<a href="results_bundle.zip" download>参数、网格与脚本</a>','参数与网格见在线版下载').replace('href="../session-hand6/"','href="https://cdh290718-oss.github.io/egofishpose-demo/session-hand6/"')
    def inline(m):
        attr,path=m.groups();p=WEB/path
        if p.is_file() and p.suffix in ['.jpg','.json','.md']:
            mime=mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
            return f'{attr}="data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"'
        return m.group(0)
    (WEB/'offline.html').write_text(re.sub(r'(src|href)="([^"]+)"',inline,offline))
    files=[p for p in OUT.iterdir() if p.suffix in ['.npz','.obj','.json','.md','.py']]
    files+=list(WEB.glob('*.jpg'))+list(WEB.glob('*.json'))+list(WEB.glob('*.md'))+[WEB/'index.html',WEB/'offline.html']
    with zipfile.ZipFile(WEB/'results_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,str(p.relative_to(OUT)))
    with zipfile.ZipFile(WEB/'results_bundle.zip') as z:assert z.testzip() is None
    write(OUT/'package_validation.json',dict(passed=True,zip_sha256=sha(WEB/'results_bundle.zip'),
        zip_bytes=(WEB/'results_bundle.zip').stat().st_size,offline_bytes=(WEB/'offline.html').stat().st_size,
        images_embedded=True,code_sha256={p.name:sha(p) for p in OUT.glob('*.py')}))
    print('DELIVERED',OUT,flush=True)

if __name__=='__main__':main()
