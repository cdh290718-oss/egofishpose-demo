"""One-frame local seam experiment: fixed MANO, deform only right forearm.

No body optimization/reinitialization, new detections, or manual targets.
"""
from pathlib import Path
import argparse, hashlib, json, sys, shutil
import numpy as np
import torch
import cv2
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from scipy.spatial.transform import Rotation

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PREV = ROOT/'experiments/session_hand6_full_pipeline_20260926_v1'
sys.path.insert(0, str(PREV/'contour'))
from contour_seam import adjacency, distance, harmonic, normals, edges, hand_metrics
from run import (read, write, load, geometry, stitch, draw_geometry, render,
                 smpl_x, SIDES, FACES, FishEyeCameraCalibrated, write_obj, read_obj,
                 edge_counts, oriented_edges, boundary_edges)

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rms(x): return float(np.sqrt(np.mean(np.asarray(x)**2)))

def setup():
    row = next(r for r in read(PREV/'baseline/automatic_input_manifest.json')['frames']
               if r['condition']=='sample_04' and r['camera']=='cam3')
    src = PREV/'contour/final_frames/sample_04/cam3'
    p, old = load(src/'body_params.npz'), load(src/'hybrid_mesh.npz')
    w = load(row['wilor_npz'])
    matches = read(PREV/'baseline/frames/sample_04/cam3/recipe.json')['matches']
    cam = FishEyeCameraCalibrated(row['calibration'])
    fresh, _ = stitch(p, w, matches, cam)
    for s in matches:
        assert np.array_equal(old[s+'_lifted_vertices'],fresh[s+'_lifted_vertices'])
    ids = old['right_local_to_mesh']; loop = old['right_wrist_loop_local']; seeds = ids[loop]
    target = fresh['right_lifted_vertices'].astype(np.float64)
    v = old['vertices_cam'].astype(np.float64)
    keep = np.ones(len(FACES), bool)
    for s in matches: keep &= ~np.isin(FACES, old[s+'_local_to_mesh']).all(1)
    bf = FACES[keep]; adj = adjacency(bf,len(v)); dist = distance(adj,seeds)
    labels=np.load(PREV/'segmentation/frames/sample_04/cam3/labels.npy')
    skin=np.isin(labels,[6,7,11,15,16,20])
    outside=cv2.distanceTransform((~skin).astype(np.uint8),cv2.DIST_L2,5)
    return dict(row=row,src=src,p=p,old=old,w=w,matches=matches,cam=cam,ids=ids,
                loop=loop,seeds=seeds,target=target,v=v,bf=bf,adj=adj,dist=dist,outside=outside)

def biharmonic(adj, known, values, free):
    # Minimize squared Laplacian of displacement; all other vertices pinned.
    rr=[]; cc=[]; vv=[]
    for i, ns in enumerate(adj):
        if not ns: continue
        rr.append(i); cc.append(i); vv.append(1.)
        for j in ns: rr.append(i); cc.append(j); vv.append(-1./len(ns))
    n=len(adj); L=coo_matrix((vv,(rr,cc)),shape=(n,n)).tocsr()
    A=L[:,free]; rhs=-(L[:,known]@values)
    disp=np.zeros((n,3)); disp[known]=values
    disp[free]=spsolve((A.T@A).tocsc(),A.T@rhs)
    return disp

def similarity_warp(c, free):
    old=c['v']; seeds=c['seeds']; x=old[seeds]; y=c['target'][c['loop']]
    xc=x.mean(0); yc=y.mean(0); a=x-xc; b=y-yc
    u,sv,vt=np.linalg.svd(a.T@b); rot=u@vt
    if np.linalg.det(rot)<0: u[:,-1]*=-1; rot=u@vt
    scale=float(np.sum((a@rot)*b)/np.sum(a*a))
    rv=Rotation.from_matrix(rot.T).as_rotvec()
    t=harmonic(c['adj'],seeds,np.ones((len(seeds),3)),free)[:,0]
    t=t*t*(3-2*t)
    rotations=Rotation.from_rotvec(t[:,None]*rv).as_matrix()
    vv=np.einsum('nij,nj->ni',rotations,old-xc)*np.exp(t*np.log(scale))[:,None]+xc+t[:,None]*(yc-xc)
    residual=y-vv[seeds]
    vv+=harmonic(c['adj'],seeds,residual,free)
    return vv-old

def repair_surface(c, free, disp, use_silhouette=False):
    # Optimize only the small body patch; MANO and all other vertices fixed.
    old=c['v']; initial=old.copy();initial[free]+=disp[free];initial[c['ids']]=c['target']
    support=np.r_[c['seeds'],free]
    faces=c['bf'][np.isin(c['bf'],support).any(1)]
    used=np.unique(faces);inv=np.full(len(old),-1,int);inv[used]=np.arange(len(used))
    f=torch.tensor(inv[faces],dtype=torch.long);e=torch.tensor(inv[edges(faces)],dtype=torch.long)
    fidx=torch.tensor(inv[free],dtype=torch.long)
    base=torch.tensor(initial[used],dtype=torch.float64)
    ref=torch.tensor(old[used],dtype=torch.float64)
    n0=torch.cross(ref[f[:,1]]-ref[f[:,0]],ref[f[:,2]]-ref[f[:,0]],dim=1)
    area0=n0.norm(dim=1);elen=(ref[e[:,0]]-ref[e[:,1]]).norm(dim=1)
    x=torch.nn.Parameter(base[fidx].clone());start=x.detach().clone()
    optimizer=torch.optim.LBFGS([x],lr=.5,max_iter=450 if use_silhouette else 220,tolerance_grad=1e-10,tolerance_change=1e-12,line_search_fn='strong_wolfe')
    if use_silhouette:
        import torch.nn.functional as TF
        sil=read(c['src']/'silhouette_targets.json')['right']
        goal=torch.tensor([b[k] for b in sil['bins'] for k in ['left','right']],dtype=torch.float64)
        full=torch.tensor(old,dtype=torch.float64)
        silids=torch.tensor(sil['vertex_ids'],dtype=torch.long)
        image_map=torch.tensor(c['outside'],dtype=torch.float64)[None,None]
        smrows=[]; smcols=[]; smvals=[]
        for i,global_id in enumerate(used):
            ns=c['adj'][global_id]
            if not ns:continue
            smrows.append(i);smcols.append(i);smvals.append(1.)
            for j in ns:
                if inv[j]>=0:smrows.append(i);smcols.append(inv[j]);smvals.append(-1./len(ns))
        lap=torch.tensor(coo_matrix((smvals,(smrows,smcols)),shape=(len(used),len(used))).toarray(),dtype=torch.float64)
    def closure():
        optimizer.zero_grad();v=base.clone();v[fidx]=x
        nn=torch.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]],dim=1)
        er=(v[e[:,0]]-v[e[:,1]]).norm(dim=1)/elen
        ar=nn.norm(dim=1)/area0;orient=(nn*n0).sum(1)/(area0**2)
        loss=.02*((x-start)/.01).square().mean()
        loss+=200*((torch.relu(er-1.38)**2).sum()+(torch.relu(.25-er)**2).sum())
        loss+=200*((torch.relu(.10-ar)**2).sum()+(torch.relu(ar-2.15)**2).sum())
        loss+=200*(torch.relu(.04-orient)**2).sum()
        if use_silhouette:
            fullv=full.clone();fullv[torch.tensor(used,dtype=torch.long)]=v
            uv=c['cam'].world2camera_pytorch(fullv[silids])
            grid=uv/uv.new_tensor([1279.,719.])*2-1
            outside=TF.grid_sample(image_map,grid.reshape(1,1,-1,2),align_corners=True,padding_mode='border').reshape(-1)
            loss+=2*(outside/10).square().mean()
            loss+=.25*(torch.cdist(goal[None],uv[None])[0].min(1).values/10).square().mean()
            loss+=.04*(lap@(v-ref)/.002).square().mean()
        loss.backward();return loss
    optimizer.step(closure)
    result=initial.copy();result[free]=x.detach().numpy()
    return result-old

def quality(v, c, support):
    ids, seeds, target, old = c['ids'],c['seeds'],c['target'],c['v']
    touched=c['bf'][np.isin(c['bf'],support).any(1)]
    ee=edges(touched); n0=normals(old,touched); nn=normals(v,touched)
    er=np.linalg.norm(v[ee[:,0]]-v[ee[:,1]],axis=1)/np.linalg.norm(old[ee[:,0]]-old[ee[:,1]],axis=1)
    ar=np.linalg.norm(nn,axis=1)/np.maximum(1e-12,np.linalg.norm(n0,axis=1))
    uv=c['cam'].world2camera(v[seeds].astype(np.float64)).astype(np.float32)
    dd=cv2.remap(c['outside'],uv[:,0,None],uv[:,1,None],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE).ravel()
    px=c['cam'].world2camera((smpl_x.orig_hand_regressor['right']@v).astype(np.float64))
    goal=c['w']['joints_2d'][c['matches']['right']['candidate']]
    rad=lambda x:float(np.linalg.norm(x-x.mean(0),axis=1).mean())
    return dict(right_hand_rmse_px=rms(np.linalg.norm(px-goal,axis=1)),
        wrist_loop_outside_rms_px=rms(dd),wrist_radius_m=rad(v[seeds]),
        mano_target_wrist_radius_m=rad(target[c['loop']]),
        wrist_to_mano_radius_ratio=rad(v[seeds])/rad(target[c['loop']]),
        wrist_to_mano_max_abs_m=float(np.abs(v[seeds]-target[c['loop']]).max()),
        hand=hand_metrics(v[ids],target,np.asarray(c['w']['mano_faces'])),
        forearm_edge_ratio_min=float(er.min()),forearm_edge_ratio_max=float(er.max()),
        forearm_area_ratio_min=float(ar.min()),forearm_area_ratio_max=float(ar.max()),
        forearm_normals_opposite_previous=int((np.sum(n0*nn,axis=1)<=0).sum()),
        forearm_minimum_double_area_m2=float(np.linalg.norm(nn,axis=1).min()),
        minimum_z_m=float(v[:,2].min()),maximum_displacement_m=float(np.linalg.norm(v-old,axis=1).max()))

def candidates(c):
    out=[]; old=c['v']; seeds=c['seeds']; delta=c['target'][c['loop']]-old[seeds]
    weights=smpl_x.layer['neutral'].lbs_weights.detach().cpu().numpy()
    eligible=weights[:,19]+weights[:,21]>.5
    allhands=np.concatenate([c['old'][s+'_local_to_mesh'] for s in SIDES])
    eligible[allhands]=False
    for rings in [6,10,14,18,24]:
        free=np.where((c['dist']>0)&(c['dist']<rings)&eligible)[0]
        for name, solver in [('harmonic',harmonic),('biharmonic',biharmonic),('similarity',None),('similarity_refined',None),('silhouette_refined',harmonic)]:
            disp=similarity_warp(c,free) if solver is None else solver(c['adj'],seeds,delta,free)
            if name=='similarity_refined': disp=repair_surface(c,free,disp)
            if name=='silhouette_refined': disp=repair_surface(c,free,disp,True)
            v=old.copy();v[free]+=disp[free];v[c['ids']]=c['target']
            support=np.r_[seeds,free];q=quality(v,c,support)
            # The old 85%-standard-radius and .7-edge floor conflict with the
            # requested hard MANO boundary. Allow local shrinkage, retain caps
            # on extension, positive depth, nondegeneracy and orientation.
            ok=bool(np.isfinite(v).all() and q['minimum_z_m']>=.02
                and q['forearm_edge_ratio_min']>=.2 and q['forearm_edge_ratio_max']<=1.4
                and q['forearm_area_ratio_min']>=.08 and q['forearm_area_ratio_max']<=2.2
                and q['forearm_normals_opposite_previous']==0
                and q['hand']['normal_reversals_vs_target']==0)
            # Fixed automatic forearm region, shared by every candidate.
            patch=np.where((c['dist']>0)&(c['dist']<24)&eligible)[0]
            uv=c['cam'].world2camera(v[patch].astype(np.float64)).astype(np.float32)
            d=cv2.remap(c['outside'],uv[:,0,None],uv[:,1,None],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE).ravel()
            # Curvature of displacement at free vertices and their neighbours.
            dp=v-old; rows=np.unique(np.concatenate([support]+[list(c['adj'][i]) for i in support])).astype(int)
            curv=[dp[i]-np.mean(dp[list(c['adj'][i])],0) for i in rows if c['adj'][i]]
            q.update(method=name,rings=rings,free_forearm_vertices=len(free),accepted=ok,
                     local_forearm_outside_rms_px=rms(d),displacement_laplacian_rms_m=rms(curv))
            q['selection_score']=q['local_forearm_outside_rms_px']+1000*q['displacement_laplacian_rms_m']
            out.append((q,v,free))
            print(json.dumps(q),flush=True)
    return out

def reconstruct_selected(c, q):
    weights=smpl_x.layer['neutral'].lbs_weights.detach().cpu().numpy()
    eligible=weights[:,19]+weights[:,21]>.5
    eligible[np.concatenate([c['old'][s+'_local_to_mesh'] for s in SIDES])]=False
    free=np.where((c['dist']>0)&(c['dist']<q['rings'])&eligible)[0]
    seeds=c['seeds'];delta=c['target'][c['loop']]-c['v'][seeds]
    name=q['method']
    if name=='safe_to_contour_blend':
        _,a,_=reconstruct_selected(c,dict(method='similarity_refined',rings=6))
        _,b,_=reconstruct_selected(c,dict(method='silhouette_refined',rings=18))
        return q,a+q['blend_fraction']*(b-a),free
    if name.startswith('similarity'):disp=similarity_warp(c,free)
    elif name=='biharmonic':disp=biharmonic(c['adj'],seeds,delta,free)
    else:disp=harmonic(c['adj'],seeds,delta,free)
    if name=='similarity_refined':disp=repair_surface(c,free,disp)
    elif name.startswith('silhouette'):disp=repair_surface(c,free,disp,True)
    v=c['v'].copy();v[free]+=disp[free];v[c['ids']]=c['target']
    if name=='silhouette_radial_clearance':
        profile=np.sin(np.pi*np.clip(c['dist'][free]/q['radial_support_rings'],0,1))
        v[free]+=q['radial_amplitude_m']*profile[:,None]*v[free]/np.linalg.norm(v[free],axis=1)[:,None]
    return q,v,free

def bounded_blend(c):
    from audit_mesh import local_intersections
    _,a,_=reconstruct_selected(c,dict(method='similarity_refined',rings=6))
    _,b,free=reconstruct_selected(c,dict(method='silhouette_refined',rings=18))
    options=[]
    for fraction in np.linspace(0,1,21):
        v=a+fraction*(b-a);q=quality(v,c,np.r_[c['seeds'],free])
        uv=c['cam'].world2camera(v[free].astype(np.float64)).astype(np.float32)
        d=cv2.remap(c['outside'],uv[:,0,None],uv[:,1,None],cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE).ravel()
        q.update(method='safe_to_contour_blend',rings=18,free_forearm_vertices=len(free),blend_fraction=float(fraction),
                 local_forearm_outside_rms_px=rms(d),selection_score=rms(d))
        ok=bool(q['minimum_z_m']>=.02 and q['forearm_edge_ratio_min']>=.2 and q['forearm_edge_ratio_max']<=1.4
                and q['forearm_area_ratio_min']>=.08 and q['forearm_area_ratio_max']<=2.2 and q['forearm_normals_opposite_previous']==0)
        if ok:
            cross=local_intersections(v,c['old']['faces'],np.r_[c['seeds'],free])
            q['local_triangle_crossings']=cross['proper_crossings'];ok=cross['proper_crossings']==0
        q['accepted']=ok;options.append((q,v,free));print('BLEND',json.dumps(q),flush=True)
    write(OUT/'blend_candidates.json',[q for q,v,f in options])
    return min([o for o in options if o[0]['accepted']],key=lambda o:o[0]['selection_score'])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify',action='store_true');ap.add_argument('--blend',action='store_true');ap.add_argument('--search',action='store_true');a=ap.parse_args()
    c=setup()
    if a.verify:
        q,v,free=reconstruct_selected(c,read(OUT/'result.json')['after'])
    elif a.blend or not a.search:
        q,v,free=bounded_blend(c)
        options=[]
    else:
        options=candidates(c)
        from audit_mesh import local_intersections
        def audit_option(o):
            q,v,free=o
            collision=local_intersections(v,c['old']['faces'],np.r_[c['seeds'],free])
            q['local_triangle_crossings']=collision['proper_crossings']
            q['accepted']=bool(q['accepted'] and collision['proper_crossings']==0)
            return o
        eligible=[o for o in options if o[0]['accepted']]
        for o in eligible:audit_option(o)
        # Projection-preserving small radial corrections on the forearm only.
        # The hard MANO boundary stays fixed. These remove local hand/arm overlap
        # without moving the image contour or reinitializing the body.
        for q0,v0,free in sorted([o for o in eligible if o[0]['method']=='silhouette_refined'],key=lambda o:o[0]['selection_score'])[:2]:
            for support_rings in [6,10,14]:
                profile=np.sin(np.pi*np.clip(c['dist'][free]/support_rings,0,1))
                for amplitude in [.002,-.002,.005,-.005,.01,-.01,.015,-.015,.02,-.02]:
                    v=v0.copy();v[free]+=amplitude*profile[:,None]*v[free]/np.linalg.norm(v[free],axis=1)[:,None]
                    q=quality(v,c,np.r_[c['seeds'],free])
                    ok=bool(q['minimum_z_m']>=.02 and q['forearm_edge_ratio_min']>=.2 and q['forearm_edge_ratio_max']<=1.4
                            and q['forearm_area_ratio_min']>=.08 and q['forearm_area_ratio_max']<=2.2 and q['forearm_normals_opposite_previous']==0)
                    q.update(method='silhouette_radial_clearance',rings=q0['rings'],free_forearm_vertices=len(free),accepted=ok,
                             radial_support_rings=support_rings,radial_amplitude_m=amplitude,
                             local_forearm_outside_rms_px=q0['local_forearm_outside_rms_px'],
                             selection_score=q0['selection_score']+abs(amplitude)*10)
                    o=(q,v,free)
                    if ok:audit_option(o)
                    options.append(o)
                    if q['accepted']:print('CLEARANCE',json.dumps(q),flush=True)
        valid=[o for o in options if o[0]['accepted']]
        if not valid:
            if options:write(OUT/'candidate_report.json',[o[0] for o in options])
            raise RuntimeError('No local surface candidate passes the geometry checks')
        q,v,free=min(valid,key=lambda o:o[0]['selection_score'])
    mesh={k:x.copy() for k,x in c['old'].items()}
    mesh.update(vertices_cam=v.astype(np.float32),
        hand_joints_cam=np.stack([smpl_x.orig_hand_regressor[s]@v for s in SIDES]).astype(np.float32),
        method=np.array('right_MANO_hard_boundary_forearm_displacement'),
        right_transition_body_vertex_ids=free,
        right_transition_method=np.array(q['method']),right_transition_rings=np.array(q['rings']),
        right_transition_displacements=(v-c['v']).astype(np.float32))
    # The hand, including all wrist vertices, is exactly the saved MANO target.
    assert np.array_equal(mesh['vertices_cam'][c['ids']],c['old']['right_lifted_vertices'])
    outside=np.ones(len(v),bool);outside[np.r_[c['ids'],free]]=False
    assert np.array_equal(mesh['vertices_cam'][outside],c['old']['vertices_cam'][outside])
    counts=edge_counts(mesh['faces']);directions=oriented_edges(mesh['faces'])
    for a0,b0 in boundary_edges(c['w']['mano_faces']):
        i,j=int(c['ids'][a0]),int(c['ids'][b0])
        assert counts[tuple(sorted((i,j)))]==2 and directions[i,j]==directions[j,i]==1
    if a.verify:
        saved=load(OUT/'hybrid_mesh.npz')
        assert set(saved)==set(mesh)
        for k in mesh:assert np.array_equal(saved[k],mesh[k]),k
        ov,of=read_obj(OUT/'hybrid_mesh.obj')
        assert np.array_equal(of,mesh['faces']) and np.abs(ov-mesh['vertices_cam']).max()<1e-7
        write(OUT/'reload_validation.json',dict(passed=True,independent_process_rebuild=True,
            mesh_max_abs_m=0.,obj_max_abs_m=float(np.abs(ov-mesh['vertices_cam']).max()),
            body_params_sha256_unchanged=sha(OUT/'body_params.npz')==sha(c['src']/'body_params.npz'),
            mano_hand_bitwise_equal_to_target=True,topology_unchanged=True,
            seam_edges_two_opposite_faces=True,unchanged_outside_local_patch=True))
        print('VERIFIED',flush=True);return
    np.savez_compressed(OUT/'hybrid_mesh.npz',**mesh)
    write_obj(OUT/'hybrid_mesh.obj',mesh['vertices_cam'],mesh['faces'])
    shutil.copyfile(c['src']/'body_params.npz',OUT/'body_params.npz')
    shutil.copyfile(c['row']['wilor_npz'],OUT/'wilor_predictions.npz')
    shutil.copyfile(c['row']['calibration'],OUT/'calibration.json')
    baseline=quality(c['v'],c,np.r_[c['seeds'],free])
    if options:write(OUT/'candidate_report.json',[o[0] for o in options])
    write(OUT/'result.json',dict(frame='sample_04_cam3',video_seconds=c['row']['video_seconds'],
        side='right',manual_annotations_used=False,body_reinitialization=False,
        body_parameters_fixed=True,mano_target='existing lifted MANO; all 778 vertices fixed',
        source=str(c['src']),before=baseline,after=q,
        inputs={k:dict(path=str(p),sha256=sha(p)) for k,p in {
            'old_mesh':c['src']/'hybrid_mesh.npz','body':c['src']/'body_params.npz',
            'wilor':c['row']['wilor_npz'],'calibration':c['row']['calibration'],
            'labels':PREV/'segmentation/frames/sample_04/cam3/labels.npy'}.items()}))
    image=cv2.imread(c['row']['image']);web=OUT/'comparison';web.mkdir(exist_ok=True)
    cv2.imwrite(str(web/'input.jpg'),image)
    for name,m in [('before',c['old']),('after',mesh)]:
        cv2.imwrite(str(web/(name+'.jpg')),render(image.copy(),m['vertices_cam'].astype(np.float64),m['faces'],c['cam'],.12))
        cv2.imwrite(str(web/(name+'_skeleton.jpg')),draw_geometry(image.copy(),c['cam'],m))
    print('SELECTED',json.dumps(q),flush=True)

if __name__=='__main__': main()
